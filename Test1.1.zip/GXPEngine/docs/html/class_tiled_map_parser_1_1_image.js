var class_tiled_map_parser_1_1_image =
[
    [ "ToString", "class_tiled_map_parser_1_1_image.html#ae0d1678639045d87f8bc7d2ed79b4f43", null ],
    [ "FileName", "class_tiled_map_parser_1_1_image.html#a860601d20de8f4adbd80317bb9860875", null ],
    [ "Height", "class_tiled_map_parser_1_1_image.html#ad4b0a90e89de7b9df64ad126a34a1488", null ],
    [ "Width", "class_tiled_map_parser_1_1_image.html#a510ffb05b73ec87237b2c3524537ebaa", null ]
];