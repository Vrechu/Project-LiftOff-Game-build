var searchData=
[
  ['scale_287',['scale',['../class_g_x_p_engine_1_1_transformable.html#aecff1ea2c666c1c869099f5715ef80d2',1,'GXPEngine::Transformable']]],
  ['scalex_288',['scaleX',['../class_g_x_p_engine_1_1_transformable.html#ae8467a6cf97a80d429641a3565846347',1,'GXPEngine::Transformable']]],
  ['scaley_289',['scaleY',['../class_g_x_p_engine_1_1_transformable.html#a9eca26b4d2a05a84bf058514178ac7b1',1,'GXPEngine::Transformable']]]
];
