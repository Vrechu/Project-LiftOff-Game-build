var searchData=
[
  ['addchild_0',['AddChild',['../class_g_x_p_engine_1_1_game_object.html#ad213f53039f4a78d03e1e81d1b00ed55',1,'GXPEngine::GameObject']]],
  ['addchildat_1',['AddChildAt',['../class_g_x_p_engine_1_1_game_object.html#a407f9f417afaef615fba9852c7c4121d',1,'GXPEngine::GameObject']]],
  ['alpha_2',['alpha',['../class_g_x_p_engine_1_1_sprite.html#a780d1b1a516887c7708188add3b23b2f',1,'GXPEngine::Sprite']]],
  ['animationsprite_3',['AnimationSprite',['../class_g_x_p_engine_1_1_animation_sprite.html',1,'GXPEngine.AnimationSprite'],['../class_g_x_p_engine_1_1_animation_sprite.html#acc0836c2e802302a4110acb459bcdb69',1,'GXPEngine.AnimationSprite.AnimationSprite(string filename, int cols, int rows, int frames=-1, bool keepInCache=false, bool addCollider=true)'],['../class_g_x_p_engine_1_1_animation_sprite.html#a7589d60a00303ebb60e0a24769ae88a9',1,'GXPEngine.AnimationSprite.AnimationSprite(System.Drawing.Bitmap bitmap, int cols, int rows, int frames=-1, bool addCollider=true)']]],
  ['animsprite_4',['AnimSprite',['../class_g_x_p_engine_1_1_anim_sprite.html',1,'GXPEngine']]]
];
