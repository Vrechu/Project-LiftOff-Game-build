var searchData=
[
  ['rectangle_94',['Rectangle',['../struct_g_x_p_engine_1_1_core_1_1_rectangle.html',1,'GXPEngine::Core']]],
  ['remove_95',['Remove',['../class_g_x_p_engine_1_1_game_object.html#a2259fbe1fef900a7d5527da951934efa',1,'GXPEngine::GameObject']]],
  ['removechild_96',['RemoveChild',['../class_g_x_p_engine_1_1_game_object.html#a6dd2b18321681958c92110b4b6162efc',1,'GXPEngine::GameObject']]],
  ['render_97',['Render',['../class_g_x_p_engine_1_1_game.html#a719c9ad1c9b37a46f261e98d8d4fb4f3',1,'GXPEngine.Game.Render()'],['../class_g_x_p_engine_1_1_game_object.html#a442d88867c7be365abe6d73f9de7b923',1,'GXPEngine.GameObject.Render()']]],
  ['rendermain_98',['RenderMain',['../class_g_x_p_engine_1_1_game.html#a48096b919243880eacca09c31cf9bbc6',1,'GXPEngine::Game']]],
  ['renderrange_99',['RenderRange',['../class_g_x_p_engine_1_1_game.html#a7c90cb7f4df63b1fbc651c878caf7ddf',1,'GXPEngine::Game']]],
  ['renderwindow_100',['RenderWindow',['../class_g_x_p_engine_1_1_window.html#a610825a7ed2a81be3ab9fd7fe7e51760',1,'GXPEngine::Window']]],
  ['rotation_101',['rotation',['../class_g_x_p_engine_1_1_transformable.html#ada9991b3de129aab7b679a9bc393e347',1,'GXPEngine::Transformable']]]
];
